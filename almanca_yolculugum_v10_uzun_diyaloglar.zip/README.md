# Almanca Yolculuğum – Sohbet destekli PWA

## Netlify'a yükleme (önemli)
Bu sürümde yapay zekâ sohbeti için Netlify Function bulunur. Bu nedenle yalnızca `public` klasörünü değil, ZIP'i açtıktan sonra içindeki **proje klasörünün tamamını** Netlify'a vermelisiniz. `netlify.toml` ve `netlify/functions` klasörü gereklidir.

1. ZIP dosyasını telefon veya bilgisayarınızda bir klasöre çıkarın.
2. Netlify hesabınızda mevcut sitenizi açın. Deploys sayfasındaki manuel yükleme alanına, `netlify.toml`, `public` ve `netlify` klasörlerini birlikte içeren proje klasörünü yükleyin. Netlify Drop kullanırken oturum açmış olun; proje klasörünü sürükleyip bırakın.
3. Dağıtım tamamlandıktan sonra Site configuration / Project configuration → Environment variables bölümüne girin.
4. `GEMINI_API_KEY` adında bir değişken oluşturun ve Google AI Studio'dan aldığınız API anahtarını değer olarak ekleyin. Anahtarı `public` klasöründeki hiçbir dosyaya yazmayın.
5. Ortam değişkenini kaydettikten sonra yeniden deploy edin.
6. Siteyi Android Chrome'da açın, **Sohbet 🤖** sekmesine girin ve A1/A2 seviyesinde bir konu seçerek deneyin.

Netlify'ın fonksiyonları derleyip dağıtabilmesi için `netlify/functions` klasörünü ve `netlify.toml` dosyasını proje kökünde görmesi gerekir. Sadece `public` klasörünü yüklerseniz sohbet API'si çalışmaz. Netlify belgeleri: https://docs.netlify.com/build/functions/get-started/ ve https://docs.netlify.com/build/functions/configuration/

## Gemini API anahtarı
- Google AI Studio: https://aistudio.google.com/app/apikey
- API anahtarınızı kimseyle paylaşmayın ve sohbet mesajında göndermeyin.
- Sohbet için `gemini-3.5-flash-lite` modeli kullanılır. Google'ın ücretsiz katmanında model ve hız sınırları bulunabilir; şartlar değişebilir. Fiyatlandırma: https://ai.google.dev/gemini-api/docs/pricing
- Google'ın ücretsiz katmanında gönderilen içerik ürünlerini geliştirmek için kullanılabilir. Sohbette özel veya hassas kişisel bilgi yazmayın.

## Sohbet özellikleri
- A1, A2 ve B1 seviyeleri
- Kendini tanıtma, adres/yol sorma, seyahat/otel, tren/ulaşım, okul/kurs, kafe/restoran, alışveriş, iş/günlük hayat, doktor/eczane ve serbest sohbet
- Almanca cevap, Türkçe çeviri ve Türkçe hata açıklaması
- Hata varsa düzeltilmiş cümleyi gösterme; istenirse düzeltmeden yeni mesaja geçmeyi engelleme
- Günde 20 başarılı mesaj hakkı (bu cihazın tarayıcısında tutulur; tarayıcı verileri silinirse sayaç sıfırlanabilir)
- Sohbet geçmişi aynı cihazın tarayıcısında saklanır; “Sohbeti temizle” ile silinebilir

## Günlük limit hakkında
Günlük 20 mesaj sınırı bu ilk sürümde tarayıcı tarafında uygulanır. Bu, kişisel kullanım için pratik bir sayaçtır; hesap bazlı veya kötüye kullanıma karşı güçlü sunucu tarafı kota sistemi değildir. Site adresi başkalarıyla paylaşılırsa API kullanımı da etkilenebilir.

## Diğer uygulama bölümleri
Kelimeler, cümleler, fiiller, gramer, Excel yükleme, ilerleme kaydı ve PWA ana ekrana ekleme özellikleri korunmuştur. Uygulama verileri aynı tarayıcı ve cihazda tutulur; otomatik bulut eşitleme yoktur.

## Teknik yapı
Sohbet isteği `netlify/functions/chat.mjs` üzerinden Gemini API'ye iletilir. API anahtarı `GEMINI_API_KEY` ortam değişkeninde tutulur; tarayıcı koduna gömülmez. Statik dosyalar `public/` klasöründedir.


## V6 bağlantı kontrolü
- Gemini sohbet işlevi `gemini-3.6-flash` kararlı modelini kullanır.
- Netlify Function, `GEMINI_API_KEY` değerini yalnızca sunucu tarafında okur; anahtar tarayıcıya gönderilmez.
- Dağıtım yapıldıktan sonra `https://SITENIZ.netlify.app/.netlify/functions/chat` adresini tarayıcıda açarak `keyConfigured: true` sonucunu kontrol edebilirsiniz. Bu kontrol anahtarın Google tarafından kabul edildiğini değil, Netlify işlevinin değişkeni gördüğünü doğrular.
- Sohbet isteği başarısız olursa ekranda Google'ın hata kodu ve güvenli hata açıklaması gösterilir. API anahtarının kendisi hiçbir hata yanıtına yazılmaz.


## V7 - Hazır kalıplarla çevrimdışı sohbet
- Sohbet bölümünde yapay zekâ sohbeti ile hazır kalıp çalışması iki ayrı seçenek olarak sunulur.
- Hazır kalıp çalışması Google Gemini veya internet bağlantısı gerektirmez.
- Kendini tanıtma, kafe/restoran, otel/seyahat, yol sorma, alışveriş ve kurs konularında Türkçe cümleyi Almancaya çevirme alıştırmaları bulunur.
- Cevaplar kontrol edilir; doğru cevap gösterilebilir ve sonraki cümleye geçilebilir.
- Yapay zekâ yanıtı geçersiz biçimde gelirse sunucu, kod çitleri içindeki JSON yanıtını da ayrıştırmayı dener.


## V8 - Sohbet modları düzeltmesi
- Hazır sohbet modunun açılması artık yapay zekâ sohbetinin başlatılmasına bağlı değildir.
- Mobil tarayıcılarda gizli/görünür panellerin durumu CSS ile güvenceye alınmıştır.
- Çevrimdışı diyaloglarda doğru cevap gösterimi konu uzunluğuna göre ayarlanmıştır.
- Service Worker önbellek sürümü yenilenmiştir.


V10 güncellemesi:
- Hazır sohbet diyalogları her konu için uzatıldı (konu başına en az 15 adım).
- 'Adınız ne?' sorusunda 'Wie heißen Sie?' dahil doğal alternatifler kabul edilir.
- 'Benim cevabım da doğru' seçeneğiyle kullanıcı tarafından onaylanan alternatif cevaplar aynı cihazda kaydedilir ve aynı soru tekrar geldiğinde doğru sayılır.
- Service worker önbelleği v10 olarak güncellendi.
