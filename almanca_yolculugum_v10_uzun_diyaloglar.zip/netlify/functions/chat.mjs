const MODEL = "gemini-3.6-flash";
const MAX_MESSAGE = 600;

export default async (req) => {
  const rawKey = process.env.GEMINI_API_KEY || "";
  // Netlify arayüzüne yanlışlıkla baş/son boşluk veya tırnak eklenmişse temizle.
  const apiKey = rawKey.trim().replace(/^["']|["']$/g, "");

  // Tarayıcıdan açılarak işlevin yayımlandığı ve değişkenin tanımlı olduğu kontrol edilebilir.
  if (req.method === "GET") {
    return Response.json({
      ok: true,
      function: "chat",
      model: MODEL,
      keyConfigured: Boolean(apiKey)
    });
  }

  if (req.method !== "POST") {
    return Response.json({ error: "Bu adres yalnızca GET veya POST isteği kabul eder." }, { status: 405 });
  }

  if (!apiKey) {
    return Response.json({
      error: "Netlify bu dağıtımda GEMINI_API_KEY değişkenini göremiyor.",
      code: "NETLIFY_KEY_MISSING",
      model: MODEL
    }, { status: 503 });
  }

  let body;
  try { body = await req.json(); }
  catch { return Response.json({ error: "İstek verisi okunamadı." }, { status: 400 }); }

  const level = ["A1", "A2", "B1"].includes(body.level) ? body.level : "A1";
  const scenario = String(body.scenario || "Günlük sohbet").slice(0, 80);
  const message = String(body.message || "").trim();
  if (!message || message.length > MAX_MESSAGE) {
    return Response.json({ error: `Mesaj 1–${MAX_MESSAGE} karakter arasında olmalı.` }, { status: 400 });
  }

  const history = Array.isArray(body.history) ? body.history.slice(-12).map((m) => ({
    role: m?.role === "model" ? "model" : "user",
    parts: [{ text: String(m?.text || "").slice(0, 1600) }]
  })).filter((m) => m.parts[0].text) : [];

  const systemInstruction = `Du bist ein geduldiger Deutschlehrer für eine türkischsprachige Person. Gesprächsniveau: ${level}. Thema/Rollenspiel: ${scenario}.
Antworte auf jede Nutzernachricht mit genau einem JSON-Objekt und ohne Markdown oder Codeblock. Verwende diese Felder:
{"reply_de":"Deine nächste natürliche Gesprächsantwort auf Deutsch; passend zum Niveau, höchstens 2 kurze Sätze und eine klare Rückfrage, damit das Gespräch weitergeht.","reply_tr":"Die türkische Übersetzung deiner deutschen Antwort.","has_errors":true,"correction":"Falls der Nutzer einen Fehler gemacht hat: vollständiger korrigierter deutscher Satz; sonst leer.","explanation_tr":"Kurze, freundliche türkische Erklärung des wichtigsten Fehlers oder ein Lob, wenn alles richtig ist."}
Prüfe Rechtschreibung, Artikel, Kasus, Verbkonjugation, Wortstellung und natürliche Ausdrucksweise. Markiere nur echte oder lernrelevante Fehler; kleine stilistische Alternativen nicht als Fehler bewerten. Wenn die Nachricht Türkisch oder eine andere Sprache statt Deutsch enthält, bitte freundlich, sie auf Deutsch zu schreiben, und gib ein einfaches Beispiel. Erfinde keine persönlichen Angaben. Bleibe konsequent auf dem gewählten Niveau. Erkläre auf Türkisch. Die reply_de muss die Unterhaltung natürlich fortsetzen und darf nicht nur eine Fehlerkorrektur sein.`;

  const contents = [...history, { role: "user", parts: [{ text: message }] }];
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents,
        generationConfig: { temperature: 0.55, maxOutputTokens: 500, responseMimeType: "application/json" }
      })
    });
    const result = await response.json();
    if (!response.ok) {
      const detail = result?.error?.message || "Gemini servisi şu anda yanıt vermiyor.";
      const googleCode = result?.error?.status || result?.error?.code || "UNKNOWN";
      let friendly = detail;
      if (/API_KEY_INVALID|API key not valid|invalid api key/i.test(detail)) {
        friendly = "Google API anahtarı reddedildi. Netlify > Environment variables bölümünde GEMINI_API_KEY satırının Production değerine, Google AI Studio'daki AUTH anahtarının tamamının (başında/sonunda boşluk veya tırnak olmadan) kaydedildiğini kontrol edin ve ardından yeni deploy başlatın.";
      } else if (/PERMISSION_DENIED|SERVICE_DISABLED|has not been used|is disabled/i.test(detail)) {
        friendly = "Google projesinde Gemini API erişim izni veya Generative Language API etkinleştirmesi gerekiyor. Google AI Studio'da anahtarın bağlı olduğu projeyi kontrol edin.";
      } else if (/RESOURCE_EXHAUSTED|quota|rate limit/i.test(detail)) {
        friendly = "Gemini API kullanım kotası dolmuş veya istek sınırına ulaşılmış. Bir süre sonra tekrar deneyin ve Google AI Studio kullanım/kota bölümünü kontrol edin.";
      } else if (/NOT_FOUND|model.*not found/i.test(detail)) {
        friendly = "Seçilen Gemini modeli bu API projesinde bulunamadı. Model ayarını kontrol edin.";
      }
      return Response.json({
        error: friendly,
        googleMessage: detail,
        googleCode,
        googleHttpStatus: response.status,
        model: MODEL
      }, { status: response.status === 429 ? 429 : 502 });
    }
    const raw = result?.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("").trim();
    if (!raw) return Response.json({ error: "Yapay zekâ boş yanıt verdi. Tekrar deneyin." }, { status: 502 });
    let data;
    try { data = JSON.parse(raw); }
    catch {
      // Bazı yoğunluk/servis yanıtlarında model JSON yerine açıklama veya kod çiti döndürebilir.
      const unfenced = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
      const start = unfenced.indexOf("{");
      const end = unfenced.lastIndexOf("}");
      if (start >= 0 && end > start) {
        try { data = JSON.parse(unfenced.slice(start, end + 1)); } catch {}
      }
      if (!data) return Response.json({
        error: "Google'dan beklenen sohbet biçiminde yanıt gelmedi. Biraz sonra tekrar deneyebilirsin.",
        responsePreview: raw.slice(0, 260), model: MODEL
      }, { status: 502 });
    }
    const clean = {
      reply_de: String(data.reply_de || "").slice(0, 900),
      reply_tr: String(data.reply_tr || "").slice(0, 900),
      has_errors: Boolean(data.has_errors),
      correction: String(data.correction || "").slice(0, 600),
      explanation_tr: String(data.explanation_tr || "").slice(0, 700)
    };
    if (!clean.reply_de) return Response.json({ error: "Yapay zekâ yanıtı eksik geldi." }, { status: 502 });
    return Response.json({ data: clean });
  } catch {
    return Response.json({ error: "İnternet bağlantısı veya AI servisiyle iletişim kurulamadı." }, { status: 502 });
  }
};
